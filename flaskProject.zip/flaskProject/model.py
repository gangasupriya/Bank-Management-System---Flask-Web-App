from extensions import db


class Bank(db.Model):
    __tablename__ = 'Bank'
    bank_id = db.Column('Bank_ID', db.Integer, primary_key=True)
    name = db.Column('Name', db.String(100), nullable=False)
    headquarters_address = db.Column('Headquarters_Address', db.String(255))
    email = db.Column('Email', db.String(100))
    phone_number = db.Column('Phone_Number', db.String(15))
    branches = db.relationship('Branch', back_populates='bank')

    def to_dict(self):
        return {
            'bank_id': self.bank_id,
            'name': self.name,
            'headquarters_address': self.headquarters_address,
            'email': self.email,
            'phone_number': self.phone_number,
        }


class Branch(db.Model):
    __tablename__ = 'Branch'
    branch_id = db.Column('Branch_ID', db.Integer, primary_key=True)
    name = db.Column('Name', db.String(100), nullable=False)
    address = db.Column('Address', db.String(255))
    email = db.Column('Email', db.String(100))
    number_of_employees = db.Column('Number_of_Employees', db.Integer)
    operating_hours = db.Column('Operating_Hours', db.String(50))
    phone_number = db.Column('Phone_Number', db.String(15))
    total_assets = db.Column('Total_Assets', db.DECIMAL(15, 2))
    bank_id = db.Column('Bank_ID', db.Integer, db.ForeignKey('Bank.Bank_ID'), nullable=False)
    bank = db.relationship('Bank', back_populates='branches')
    employees = db.relationship('Employee', back_populates='branch')
    customers = db.relationship('Customer', back_populates='branch')

    def to_dict(self):
        return {
            'branch_id': self.branch_id,
            'name': self.name,
            'address': self.address,
            'email': self.email,
            'number_of_employees': self.number_of_employees,
            'operating_hours': self.operating_hours,
            'phone_number': self.phone_number,
            'total_assets': float(self.total_assets) if self.total_assets else None,
            'bank_id': self.bank_id,
        }


class Employee(db.Model):
    __tablename__ = 'Employee'
    employee_id = db.Column('Employee_ID', db.Integer, primary_key=True)
    name = db.Column('Name', db.String(100), nullable=False)
    department = db.Column('Department', db.String(50))
    email = db.Column('Email', db.String(100))
    job_type = db.Column('Job_Type', db.String(50))
    ssn = db.Column('SSN', db.String(11), unique=True, nullable=False)
    start_date = db.Column('Start_Date', db.Date)
    phone_number = db.Column('Phone_Number', db.String(15))
    address = db.Column('Address', db.String(255))
    branch_id = db.Column('Branch_ID', db.Integer, db.ForeignKey('Branch.Branch_ID'), nullable=False)
    branch = db.relationship('Branch', back_populates='employees')

    def to_dict(self):
        return {
            'employee_id': self.employee_id,
            'name': self.name,
            'department': self.department,
            'email': self.email,
            'job_type': self.job_type,
            'ssn': self.ssn,
            'start_date': self.start_date.strftime('%Y-%m-%d') if self.start_date else None,
            'phone_number': self.phone_number,
            'address': self.address,
            'branch_id': self.branch_id,
        }


class Customer(db.Model):
    __tablename__ = 'Customer'
    customer_id = db.Column('Customer_ID', db.Integer, primary_key=True)
    ssn = db.Column('SSN', db.String(11), unique=True, nullable=False)
    name = db.Column('Name', db.String(100), nullable=False)
    phone_number = db.Column('Phone_Number', db.String(15))
    account_type = db.Column('Account_Type', db.String(50))
    account_holder_type = db.Column('Account_Holder_Type', db.String(50))
    address = db.Column('Address', db.String(255))
    branch_id = db.Column('Branch_ID', db.Integer, db.ForeignKey('Branch.Branch_ID'), nullable=False)
    branch = db.relationship('Branch', back_populates='customers')
    accounts = db.relationship('Account', back_populates='customer')

    def to_dict(self):
        return {
            'customer_id': self.customer_id,
            'ssn': self.ssn,
            'name': self.name,
            'phone_number': self.phone_number,
            'account_type': self.account_type,
            'account_holder_type': self.account_holder_type,
            'address': self.address,
            'branch_id': self.branch_id,
        }


class Account(db.Model):
    __tablename__ = 'Account'
    account_number = db.Column('Account_Number', db.Integer, primary_key=True)
    account_holder_type = db.Column('Account_Holder_Type', db.String(50))
    account_type = db.Column('Account_Type', db.String(50))
    transaction_limit = db.Column('Transaction_Limit', db.DECIMAL(10, 2))
    interest_rate = db.Column('Interest_Rate', db.DECIMAL(5, 2))
    balance = db.Column('Balance', db.DECIMAL(15, 2))
    maintenance_fee = db.Column('Maintenance_Fee', db.DECIMAL(10, 2))
    customer_id = db.Column('Customer_ID', db.Integer, db.ForeignKey('Customer.Customer_ID'), nullable=False)
    customer = db.relationship('Customer', back_populates='accounts')
    transactions = db.relationship('Transaction', back_populates='account')

    def to_dict(self):
        return {
            'account_number': self.account_number,
            'account_holder_type': self.account_holder_type,
            'account_type': self.account_type,
            'transaction_limit': float(self.transaction_limit) if self.transaction_limit else None,
            'interest_rate': float(self.interest_rate) if self.interest_rate else None,
            'balance': float(self.balance) if self.balance else None,
            'maintenance_fee': float(self.maintenance_fee) if self.maintenance_fee else None,
            'customer_id': self.customer_id,
        }


class Loan(db.Model):
    __tablename__ = 'Loan'
    loan_number = db.Column('Loan_Number', db.Integer, primary_key=True)
    loan_amount = db.Column('Loan_Amount', db.DECIMAL(15, 2))
    customer_ssn = db.Column('Customer_SSN', db.String(11), db.ForeignKey('Customer.SSN'), nullable=False)
    loan_type = db.Column('Loan_Type', db.String(50))
    monthly_repayments = db.Column('Monthly_Repayments', db.DECIMAL(15, 2))
    interest_rate = db.Column('Interest_Rate', db.DECIMAL(5, 2))

    def to_dict(self):
        return {
            'loan_number': self.loan_number,
            'loan_amount': float(self.loan_amount) if self.loan_amount else None,
            'customer_ssn': self.customer_ssn,
            'loan_type': self.loan_type,
            'monthly_repayments': float(self.monthly_repayments) if self.monthly_repayments else None,
            'interest_rate': float(self.interest_rate) if self.interest_rate else None,
        }


class Transaction(db.Model):
    __tablename__ = 'Transaction'
    transaction_id = db.Column('Transaction_ID', db.Integer, primary_key=True)
    amount = db.Column('Amount', db.DECIMAL(15, 2))
    account_number = db.Column('Account_Number', db.Integer, db.ForeignKey('Account.Account_Number'), nullable=False)
    reference = db.Column('Reference', db.String(100))
    transaction_type = db.Column('Transaction_Type', db.String(50))
    method = db.Column('Method', db.String(50))
    account = db.relationship('Account', back_populates='transactions')

    def to_dict(self):
        return {
            'transaction_id': self.transaction_id,
            'amount': float(self.amount) if self.amount else None,
            'account_number': self.account_number,
            'reference': self.reference,
            'transaction_type': self.transaction_type,
            'method': self.method,
        }
