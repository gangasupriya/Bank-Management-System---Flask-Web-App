from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

from extensions import db
from model import Account, Loan, Transaction

app = Flask(__name__)
# Replace with your database credentials
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://kiran:Kiranmayee%409@192.168.1.75/bank_management'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Suppress warnings

db.init_app(app)

# Routes
@app.route('/')
def accounts():
    accounts = Account.query.all()
    return render_template('accounts.html', accounts=accounts)

@app.route('/loans')
def loans():
    loans = Loan.query.all()
    return render_template('loans.html', loans=loans)

@app.route('/transactions/<int:account_id>')
def transactions(account_id):
    transactions = Transaction.query.filter_by(account_number=account_id).all()
    return render_template('transactions.html', transactions=transactions, account_id=account_id)


if __name__ == '__main__':
    app.run()
